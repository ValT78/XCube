package com.dourak.game;

import com.badlogic.gdx.Game;
import com.dourak.game.screen.LoadingScreen;

public class Dourak extends Game {

	@Override
	public void create(){
		setScreen(new LoadingScreen(this));
	}
}
