package com.dourak.game.screen;

import com.badlogic.gdx.Screen;
import com.dourak.game.Dourak;

public abstract class AbstractScreen implements Screen {

    protected Dourak game;

    public AbstractScreen(Dourak game) {
        this.game = game;
    }
    public void pause() {}
    public void resume() {}
    public void hide() {}
}
