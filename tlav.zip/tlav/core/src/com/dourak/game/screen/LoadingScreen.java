package com.dourak.game.screen;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FillViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.dourak.game.Dourak;
import com.dourak.game.utils.AssetUtils;

import org.graalvm.compiler.word.Word;

public class LoadingScreen extends AbstractScreen {

    private static final int WORLD_WIDTH = 1280;
    private static final int WORLD_HEIGHT = 720;

    private static final int PROGRESS_BAR_WIDTH = 1000;
    private static final int PROGRESS_BAR_HEIGHT= 25;

    private ShapeRenderer shapeRenderer;
    private Viewport viewport;
    private OrthographicCamera camera;

    //State
    private float progress =0;
    private boolean doneloadingConfig=false;
    private boolean startedloadingConfig=false;

    public LoadingScreen(Dourak game) {
        super(game);
    }

    @Override
    public void show() {
        camera = new OrthographicCamera();
        camera.position.set(WORLD_WIDTH/2f, WORLD_HEIGHT/2f, 0);
        camera.update();

        viewport = new FillViewport(WORLD_WIDTH, WORLD_HEIGHT, camera);
        shapeRenderer = new ShapeRenderer();


    }

    @Override
    public void render(float delta) {
        if (AssetUtils.updateAssetLoading() && !startedloadingConfig) {
            progress = 0.9f;
            startedloadingConfig = true;
            loadConfigs();
        } else {
            progress = AssetUtils.loadProgress();
        }
        if (doneloadingConfig){
            game.setScreen(new MainGameScreen(game));
        }
        ScreenUtils.clear(0,0,0,1);
        shapeRenderer.setProjectionMatrix(camera.projection);
        shapeRenderer.setTransformMatrix(camera.view);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(Color.WHITE);
        shapeRenderer.rect(WORLD_WIDTH / 2f - PROGRESS_BAR_WIDTH, (WORLD_HEIGHT / 2f) - (PROGRESS_BAR_HEIGHT / 2f), progress * PROGRESS_BAR_WIDTH, PROGRESS_BAR_HEIGHT);
        shapeRenderer.end();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void dispose() {

    }

    private void loadConfigs(){
        doneloadingConfig = true;
    }
}
