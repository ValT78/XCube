package com.dourak.game.utils;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.assets.loaders.TextureAtlasLoader;
import com.badlogic.gdx.assets.loaders.resolvers.InternalFileHandleResolver;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;

import lombok.experimental.UtilityClass;

@UtilityClass
public class AssetUtils {
    private static String TAG = AssetUtils.class.getSimpleName();

    private static final AssetManager ASSET_MANAGER = new AssetManager();
    private static final InternalFileHandleResolver FILE_PATH_RESOLVER = new InternalFileHandleResolver();

    static {
        ASSET_MANAGER.setLoader(TiledMap.class, new TmxMapLoader());
        ASSET_MANAGER.setLoader(TextureAtlas.class, new TextureAtlasLoader(FILE_PATH_RESOLVER));
    }
    public void unloadAsset(String path) {
        if (!ASSET_MANAGER.isLoaded(path)) {
            return;
        }

        ASSET_MANAGER.unload(path);
    }

    public static float loadProgress(){
        return ASSET_MANAGER.getProgress();
    }
    public static boolean updateAssetLoading() {
        return ASSET_MANAGER.update();
    }
    public TiledMap getMapAsset(String path){
        if (!ASSET_MANAGER.isLoaded(path)){
            throw new IllegalStateException("The asset "+ path+" is not loaded");
        }
        return ASSET_MANAGER.get(path,TiledMap.class);
    }
    public void loadMapAsset(String path){
        if (!canWeLoad(path)){
            Gdx.app.error(TAG,"Cannot load asset from path:"+path);
            return;
        }
        ASSET_MANAGER.load(path,TiledMap.class);
    }
    public TextureAtlas getAtlasAsset(String path){
        if (!ASSET_MANAGER.isLoaded(path)){
            throw new IllegalStateException("The asset "+ path+" is not loaded");
        }
        return ASSET_MANAGER.get(path,TextureAtlas.class);
    }
    public void loadAtlasAsset(String path){
        if (!canWeLoad(path)){
            Gdx.app.error(TAG,"Cannot load asset from path:"+path);
            return;
        }
        ASSET_MANAGER.load(path,TextureAtlas.class);
    }
    private boolean canWeLoad(String path) {
        return path != null && !path.isEmpty() && !ASSET_MANAGER.isLoaded(path) && FILE_PATH_RESOLVER.resolve(path).exists();
    }
}
